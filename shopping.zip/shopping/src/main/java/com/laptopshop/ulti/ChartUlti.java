package com.laptopshop.ulti;

public interface ChartUlti {

}
